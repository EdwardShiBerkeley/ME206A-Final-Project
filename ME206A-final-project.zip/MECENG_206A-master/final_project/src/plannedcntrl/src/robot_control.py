#!/usr/bin/env python

import rospy
import tf2_ros
import numpy as np
import moveit_commander
import subprocess  # For launching external commands
from geometry_msgs.msg import PoseStamped
from intera_interface import gripper as robot_gripper

# Custom module imports
from calibration import calibrate_system
from trajectory_planning import calculate_trajectory
from object_tracking import track_object


class RobotControl:
    def __init__(self):
        # Initialize MoveIt! and other components
        self.group = moveit_commander.MoveGroupCommander("right_arm")
        self.gripper = robot_gripper.Gripper('right_gripper')

    def calibrate_robot(self):
        # Calibrate system using calibration.py
        calibrator = Calibration()
        calibrator.perform_calibration()

        # Calibrate the gripper
        self.gripper = robot_gripper.Gripper('right_gripper')
        rospy.loginfo("Calibrating gripper...")
        self.gripper.calibrate()
        rospy.sleep(2.0)
        rospy.loginfo("Gripper calibration complete.")

    def track_and_pick_package(self, group):
        # Subscribe to package position
        package_pos_sub = rospy.Subscriber(
            '/package_position', Point, self.package_position_callback)

        # Wait for package position update
        rospy.wait_for_message('/package_position', Point)

        # Unsubscribe to avoid processing old messages in the future
        package_pos_sub.unregister()

        # Assuming self.target_position is updated in package_position_callback
        if self.target_position:
            # Calculate the trajectory to intercept the package
            interception_point = self.calculate_interception_point(
                self.target_position)
            self.move_robot(group, interception_point)

            # Perform gripping action
            self.gripper.close()
            rospy.sleep(1.0)  # Wait for gripper to close

    def package_position_callback(self, msg):
        # Update the target position of the package
        self.target_position = msg

    def select_bin(self, package_ar_id):
        if package_ar_id == "ar_marker_id_1":  # Replace with actual AR marker ID for the first bin
            return self.bin_position_1
        elif package_ar_id == "ar_marker_id_2":  # Replace with AR marker ID for the second bin
            return self.bin_position_2
        else:
            rospy.logwarn("Unknown package AR marker. Defaulting to bin 1.")
            return self.bin_position_1

    def place_in_bin(self, group, bin_position):
        # Assuming the robot is holding the package
        bin_position = self.select_bin(package_criteria)
        bin_pose = PoseStamped()
        bin_pose.header.frame_id = "base"
        bin_pose.pose.position = bin_position
        bin_pose.pose.orientation.w = 1.0  # Adjust orientation as needed

        # Move to bin position
        group.set_pose_target(bin_pose)
        group.go(wait=True)

        # Release the gripper to drop the package
        self.gripper.open()
        rospy.sleep(1.0)  # Wait for the gripper to open

        # Optionally, move the arm to a safe position after releasing

    # Hardcode this with Tf echo position of the bins
    bin_position_1 = Point(x=1.0, y=0.5, z=0.3)  # Bin 1 coordinates
    bin_position_2 = Point(x=1.2, y=0.6, z=0.3)  # Bin 2 coordinates

    def tuck_robot(self):
        # Use subprocess to launch 'sawyer_tuck.launch'
        subprocess.call(["roslaunch", "intera_examples", "sawyer_tuck.launch"])

    def main_loop(self):
        while not rospy.is_shutdown():
            # Main operation loop
            self.track_and_pick_package(self.group)
            self.place_in_bin(self.group, self.package_ar_id)
            self.tuck_robot()
            rospy.sleep(1)  # Adjust as necessary


if __name__ == '__main__':
    rospy.init_node('robot_control')
    controller = RobotControl()
    controller.calibrate_robot()
    controller.main_loop()
