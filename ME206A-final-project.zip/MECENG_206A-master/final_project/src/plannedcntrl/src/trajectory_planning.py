#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Point
from some_kinematics_library import Kinematics
import numpy as np


class TrajectoryPlanner:
    def __init__(self):
        self.package_position_subscriber = rospy.Subscriber(
            '/package_position', Point, self.package_position_callback)
        self.kinematics = Kinematics()  # Replace with actual kinematics class/library
        self.last_package_position = None

    def package_position_callback(self, position):
        if self.last_package_position is not None:
            velocity = self.calculate_velocity(
                self.last_package_position, position)
            future_position = self.predict_future_position(position, velocity)
            interception_point = self.calculate_interception_point(
                future_position)
            self.plan_robot_trajectory(interception_point)
        self.last_package_position = position

    def calculate_velocity(self, last_position, current_position):
        # Assuming positions are provided as Point messages and have x, y, z coordinates
        delta_x = current_position.x - last_position.x
        delta_y = current_position.y - last_position.y
        delta_z = current_position.z - last_position.z

        # Calculate the time difference
        current_time = rospy.get_time()
        # self.last_time needs to be stored in the callback
        time_diff = current_time - self.last_time

        # Calculate velocity components
        velocity_x = delta_x / time_diff
        velocity_y = delta_y / time_diff
        velocity_z = delta_z / time_diff

        # Store the current time for the next calculation
        self.last_time = current_time

        return Point(x=velocity_x, y=velocity_y, z=velocity_z)

    def predict_future_position(self, current_position, velocity):
        # Define a prediction time interval (in seconds)
        prediction_interval = 1.0  # Adjust this based on your system's responsiveness and speed

        # Calculate future position components
        future_x = current_position.x + (velocity.x * prediction_interval)
        future_y = current_position.y + (velocity.y * prediction_interval)
        future_z = current_position.z + (velocity.z * prediction_interval)

        return Point(x=future_x, y=future_y, z=future_z)

    def calculate_interception_point(self, future_position):
        # Assuming the robot's reachability and speed are known
        # For simplicity, this example assumes the interception point is the future position of the package
        # In a real scenario, adjust this to account for the robot's time to reach the position and its reach limits

        interception_x = future_position.x
        interception_y = future_position.y
        # Consider if the gripper needs to be at a specific height to pick up the package
        interception_z = future_position.z

        return Point(x=interception_x, y=interception_y, z=interception_z)

    def plan_robot_trajectory(self, interception_point):
        # Initialize the MoveIt! interface with the correct move group
        # This is a common group name for Sawyer
        move_group = MoveGroupCommander("right_arm")

        # Set the target position in the appropriate reference frame
        target_pose = PoseStamped()
        # Using 'base' as the reference frame for Sawyer
        target_pose.header.frame_id = "base"
        target_pose.pose.position = interception_point
        # Optionally set the desired orientation for the gripper

        # Plan the trajectory to the target position
        move_group.set_pose_target(target_pose)
        plan = move_group.plan()

        # Execute the plan
        move_group.execute(plan, wait=True)


if __name__ == '__main__':
    rospy.init_node('trajectory_planner')
    planner = TrajectoryPlanner()
    rospy.spin()
