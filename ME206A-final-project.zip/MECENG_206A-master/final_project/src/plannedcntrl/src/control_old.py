#!/usr/bin/env python
#The line above tells Linux that this file is a Python script,
#and that the OS should use the Python interpreter in /usr/bin/env
#to run it. Don't forget to use "chmod +x [filename]" to make
#this script executable.

#Import the rospy package. For an import to work, it must be specified
#in both the package manifest AND the Python file in which it is used.
import rospy
import tf2_ros
import tf
import sys
import numpy as np
import moveit_commander
from geometry_msgs.msg import TransformStamped, PoseStamped, Twist, Point, TransformStamped, Transform
from tf.transformations import quaternion_from_euler
from tf2_geometry_msgs import do_transform_pose
from trajectory import plan_curved_trajectory
from moveit_msgs.srv import GetPositionIK, GetPositionIKRequest, GetPositionIKResponse
from moveit_commander import MoveGroupCommander
from numpy import linalg
from intera_interface import gripper as robot_gripper
from scipy.spatial.transform import Rotation as R

def test(package_in_base, velocity, t, right_gripper):
    ts= rospy.Time.now().to_sec()
    print("start")
    # Wait for the IK service to become available
    rospy.wait_for_service('compute_ik')
    # rospy.init_node('service_query')
    # Create the function used to call the service
    compute_ik = rospy.ServiceProxy('compute_ik', GetPositionIK)
    # while not rospy.is_shutdown():
    # input('Press [ Enter ]: ')
    
    # Construct the request
    request = GetPositionIKRequest()
    request.ik_request.group_name = "right_arm"

    # If a Sawyer does not have a gripper, replace '_gripper_tip' with '_wrist' instead
    link = "right_gripper_tip"

    request.ik_request.ik_link_name = link
    # request.ik_request.attempts = 20
    request.ik_request.pose_stamped.header.frame_id = "base"
    
    tf = rospy.Time.now().to_sec()

    # Set the desired orientation for the end effector HERE
    request.ik_request.pose_stamped.pose.position.x = package_in_base[0] 
    # request.ik_request.pose_stamped.pose.position.y = package_in_base[1] + velocity*(t+tf-ts+6) # static offset 1.5, dynamic offset (based on robot move speed) + 3.5
    request.ik_request.pose_stamped.pose.position.y = package_in_base[1] + velocity*(t+tf-ts+4) # static offset 1.5, dynamic offset (based on robot move speed) + 3.5
    request.ik_request.pose_stamped.pose.position.z = package_in_base[2] + 0.1
    request.ik_request.pose_stamped.pose.orientation.x = -1.0/np.sqrt(2)
    request.ik_request.pose_stamped.pose.orientation.y = 1.0/np.sqrt(2)
    request.ik_request.pose_stamped.pose.orientation.z = 0.0
    request.ik_request.pose_stamped.pose.orientation.w = 0.0       
    # request.ik_request.pose_stamped.pose.orientation.x = 0.0
    # request.ik_request.pose_stamped.pose.orientation.y = 1.0
    # request.ik_request.pose_stamped.pose.orientation.z = 0.0
    # request.ik_request.pose_stamped.pose.orientation.w = 0.0
    
    try:
        # Send the request to the service
        response = compute_ik(request)
        
        # Print the response HERE
        print(response)
        group = MoveGroupCommander("right_arm")

        # Setting position and orientation target
        group.set_pose_target(request.ik_request.pose_stamped)

        # TRY THIS
        # Setting just the position without specifying the orientation
        ###group.set_position_target([0.5, 0.5, 0.0])

        # Plan IK
        plan = group.plan()
        group.limit_max_cartesian_link_speed(5)
        plan = group.retime_trajectory(moveit_commander.RobotCommander().get_current_state(), plan[1], 0.5)
        print(request.ik_request.pose_stamped.pose.position.x)
        print(request.ik_request.pose_stamped.pose.position.y)
        print(request.ik_request.pose_stamped.pose.position.z)
        # user_input = input("Enter 'y' if the trajectory looks safe on RVIZ")
        group.execute(plan)
        
        # # Execute IK if safe
        # if user_input == 'y':
        #     group.execute(plan[1])
                    
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)

        # rospy.sleep(10)
    # Set the desired orientation for the end effector HERE
    request.ik_request.pose_stamped.pose.position.z = package_in_base[2]
    
    try:
        # Send the request to the service
        response = compute_ik(request)
        
        # Print the response HERE
        print(response)
        group = MoveGroupCommander("right_arm")

        # Setting position and orientation target
        group.set_pose_target(request.ik_request.pose_stamped)

        # TRY THIS
        # Setting just the position without specifying the orientation
        ###group.set_position_target([0.5, 0.5, 0.0])

        # Plan IK
        plan = group.plan()
        group.limit_max_cartesian_link_speed(5)
        plan = group.retime_trajectory(moveit_commander.RobotCommander().get_current_state(), plan[1], 0.5)
        print(request.ik_request.pose_stamped.pose.position.x)
        print(request.ik_request.pose_stamped.pose.position.y)
        print(request.ik_request.pose_stamped.pose.position.z)
        # user_input = input("Enter 'y' if the trajectory looks safe on RVIZ")
        group.execute(plan)
        
        # # Execute IK if safe
        # if user_input == 'y':
        #     group.execute(plan[1])
                    
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)


    # Close the right gripper
    print('Closing...')
    right_gripper.close()
    rospy.sleep(1.0)

    # Set the desired orientation for the end effector HERE
    request.ik_request.pose_stamped.pose.position.z = package_in_base[2] + 0.1
    
    try:
        # Send the request to the service
        response = compute_ik(request)
        
        # Print the response HERE
        print(response)
        group = MoveGroupCommander("right_arm")

        # Setting position and orientation target
        group.set_pose_target(request.ik_request.pose_stamped)

        # TRY THIS
        # Setting just the position without specifying the orientation
        ###group.set_position_target([0.5, 0.5, 0.0])

        # Plan IK
        plan = group.plan()
        group.limit_max_cartesian_link_speed(5)
        plan = group.retime_trajectory(moveit_commander.RobotCommander().get_current_state(), plan[1], 0.5)
        print(request.ik_request.pose_stamped.pose.position.x)
        print(request.ik_request.pose_stamped.pose.position.y)
        print(request.ik_request.pose_stamped.pose.position.z)
        # user_input = input("Enter 'y' if the trajectory looks safe on RVIZ")
        group.execute(plan)
        
        # # Execute IK if safe
        # if user_input == 'y':
        #     group.execute(plan[1])
                    
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)


    # Open the right gripper
    print('Opening...')
    right_gripper.open()
    rospy.sleep(1.0)


        # request.ik_request.pose_stamped.pose.position.x = 0.858
        # request.ik_request.pose_stamped.pose.position.y = 0
        # request.ik_request.pose_stamped.pose.position.z = 0       
        # request.ik_request.pose_stamped.pose.orientation.x = 0.0
        # request.ik_request.pose_stamped.pose.orientation.y = 1.0
        # request.ik_request.pose_stamped.pose.orientation.z = 0.0
        # request.ik_request.pose_stamped.pose.orientation.w = 0.0

        # try:
        #     # Send the request to the service
        #     response = compute_ik(request)
            
        #     # Print the response HERE
        #     print(response)
        #     group = MoveGroupCommander("right_arm")

        #     # Setting position and orientation target
        #     group.set_pose_target(request.ik_request.pose_stamped)

        #     # TRY THIS
        #     # Setting just the position without specifying the orientation
        #     ###group.set_position_target([0.5, 0.5, 0.0])

        #     # Plan IK
        #     plan = group.plan()
        #     user_input = input("Enter 'y' if the trajectory looks safe on RVIZ")
        
        #     # Execute IK if safe
        #     if user_input == 'y':
        #         group.execute(plan[1])
                        
        # except rospy.ServiceException as e:
        #     print("Service call failed: %s"%e)

        # request.ik_request.pose_stamped.pose.position.x = 0.858
        # request.ik_request.pose_stamped.pose.position.y = -0.151
        # request.ik_request.pose_stamped.pose.position.z = -0.157       
        # request.ik_request.pose_stamped.pose.orientation.x = 0.0
        # request.ik_request.pose_stamped.pose.orientation.y = 1.0
        # request.ik_request.pose_stamped.pose.orientation.z = 0.0
        # request.ik_request.pose_stamped.pose.orientation.w = 0.0

        # try:
        #     # Send the request to the service
        #     response = compute_ik(request)
            
        #     # Print the response HERE
        #     print(response)
        #     group = MoveGroupCommander("right_arm")

        #     # Setting position and orientation target
        #     group.set_pose_target(request.ik_request.pose_stamped)

        #     # TRY THIS
        #     # Setting just the position without specifying the orientation
        #     ###group.set_position_target([0.5, 0.5, 0.0])

        #     # Plan IK
        #     plan = group.plan()
        #     user_input = input("Enter 'y' if the trajectory looks safe on RVIZ")
        
        #     # Execute IK if safe
        #     if user_input == 'y':
        #         group.execute(plan[1])
                        
        # except rospy.ServiceException as e:
        #     print("Service call failed: %s"%e)

                

        # # Open the right gripper
        # print('Opening...')
        # right_gripper.open()
        # rospy.sleep(1.0)
        # print('Done!')

def controller():
    tfBuffer = tf2_ros.Buffer() ## TODO: initialize a buffer
    tfListener = tf2_ros.TransformListener(tfBuffer) ## TODO: initialize a tf listener

    # Create a timer object that will sleep long enough to result in
    # a 10Hz publishing rate
    r = rospy.Rate(10) # 10hz
    # you can also use the rate to calculate your dt, but you don't have to
    #                                              target_frame, source_frame, current_time_in_ros
    trans_camera_to_base = tfBuffer.lookup_transform("ar_marker_0", "usb_cam", rospy.Time(), rospy.Duration(10)) ## TODO: create a transform between odom to base link
    # while not rospy.is_shutdown():
    try:
        package_in_base_mat = calculate("ar_marker_6", tfBuffer, trans_camera_to_base)
        return package_in_base_mat
        # trans_package_to_camera0 = tfBuffer.lookup_transform("usb_cam", "ar_marker_0", rospy.Time(), rospy.Duration(1))
        # trans_package_to_camera0_coords = [trans_package_to_camera0.transform.translation.x,trans_package_to_camera0.transform.translation.y,trans_package_to_camera0.transform.translation.z]
        # # print(abs(np.linalg.norm(trans_package_to_camera0_coords-prev))
        # # a = abs(np.linalg.norm(trans_package_to_camera0_coords - prev))
        # prev = [trans_package_to_camera0]
        # if trans_package_to_camera0 == prev:
        #     trans_package_to_camera0 = None
        # # trans_package_to_camera1 = tfBuffer.lookup_transform("usb_cam", "ar_marker_1", rospy.Time(), rospy.Duration(10))
        # # trans_package_to_camera2 = tfBuffer.lookup_transform("usb_cam", "ar_marker_2", rospy.Time(), rospy.Duration(10))

        # if trans_package_to_camera0 == None:
        #     trans_package_to_camera_arr = []
        # else:
        #     trans_package_to_camera_arr = [trans_package_to_camera0]

        # package_trans_arr = []

        # for i in range(len(trans_package_to_camera_arr)):
        #     package_trans = PoseStamped() ## TODO: initialize a PoseStamped
        #     package_trans.pose.position.x = trans_package_to_camera_arr[i].transform.translation.x ## TODO: what value would you use here?
        #     package_trans.pose.position.y = trans_package_to_camera_arr[i].transform.translation.y ## TODO: what value would you use here?
        #     package_trans.pose.position.z = trans_package_to_camera_arr[i].transform.translation.z ## TODO: what value would you use here?  # Assuming the waypoint is on the ground
        #     package_trans.pose.orientation.x = trans_package_to_camera_arr[i].transform.rotation.x ## TODO: what value would you use here?
        #     package_trans.pose.orientation.y = trans_package_to_camera_arr[i].transform.rotation.y ## TODO: what value would you use here?
        #     package_trans.pose.orientation.z = trans_package_to_camera_arr[i].transform.rotation.z ## TODO: what value would you use here?
        #     package_trans.pose.orientation.w = trans_package_to_camera_arr[i].transform.rotation.w ## TODO: what value would you use here?

        #     package_in_base = do_transform_pose(package_trans, trans_camera_to_base) ## TODO: what would be the inputs to this function (there are 2)
        #     print(f"Target: {package_in_base.pose.position.x}, {package_in_base.pose.position.y}, {package_in_base.pose.position.z}")
        #     # print(f"Target: {trans_package_to_base.transform.translation.x}, {trans_package_to_base.transform.translation.y}, {trans_package_to_base.transform.translation.z}")


        #     rotation_matrix = np.array([[0,0,1],[1,0,0],[0,1,0]])
        #     # NOTE: MANUALLY FIND OFFSET BY PUTTING ROBOT END EFFECTOR TO AR BASE TAG AND ADDING OFFSET VALUES BELOW
        #     translation_vector = np.array([0.143, -0.006, 0.0+0.05])
        #     package_in_base_coords = [0.257*package_in_base.pose.position.x, 0.257*package_in_base.pose.position.y, 0.257*package_in_base.pose.position.z]
        #     package_in_base_mat = rotation_matrix@package_in_base_coords + translation_vector
        #     print(f"Target: {package_in_base_mat[0]}, {package_in_base_mat[1]}, {package_in_base_mat[2]}")
        #     return package_in_base_mat
        rospy.sleep(0.1)
    except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
      # print("TF Error in Controller: " + str(e))
      pass
    try:
        package_in_base_mat = calculate("ar_marker_2", tfBuffer, trans_camera_to_base)
        return package_in_base_mat
        rospy.sleep(0.1)
    except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
      # print("TF Error in Controller: " + str(e))
      pass
    
def calculate(ar_tag, tfBuffer, trans_camera_to_base):
    trans_package_to_camera = tfBuffer.lookup_transform("usb_cam", ar_tag, rospy.Time(), rospy.Duration(1))

    package_trans = PoseStamped() ## TODO: initialize a PoseStamped
    package_trans.pose.position.x = trans_package_to_camera.transform.translation.x ## TODO: what value would you use here?
    package_trans.pose.position.y = trans_package_to_camera.transform.translation.y ## TODO: what value would you use here?
    package_trans.pose.position.z = trans_package_to_camera.transform.translation.z ## TODO: what value would you use here?  # Assuming the waypoint is on the ground
    package_trans.pose.orientation.x = trans_package_to_camera.transform.rotation.x ## TODO: what value would you use here?
    package_trans.pose.orientation.y = trans_package_to_camera.transform.rotation.y ## TODO: what value would you use here?
    package_trans.pose.orientation.z = trans_package_to_camera.transform.rotation.z ## TODO: what value would you use here?
    package_trans.pose.orientation.w = trans_package_to_camera.transform.rotation.w ## TODO: what value would you use here?

    package_in_base = do_transform_pose(package_trans, trans_camera_to_base) ## TODO: what would be the inputs to this function (there are 2)
    # print(f"Target: {package_in_base.pose.position.x}, {package_in_base.pose.position.y}, {package_in_base.pose.position.z}")
    # print(f"Target: {trans_package_to_base.transform.translation.x}, {trans_package_to_base.transform.translation.y}, {trans_package_to_base.transform.translation.z}")


    rotation_matrix = np.array([[0,0,1],[1,0,0],[0,1,0]])
    # NOTE: MANUALLY FIND OFFSET BY PUTTING ROBOT END EFFECTOR TO AR BASE TAG AND ADDING OFFSET VALUES BELOW
    translation_vector = np.array([0.143-0.15, -0.006-0.005, 0.0-0.03])
    # translation_vector = np.array([0.143-2.15, -0.006-0.005, 0.0-0.01+0.8])
    scale = 0.257
    package_in_base_coords = [scale*package_in_base.pose.position.x, scale*package_in_base.pose.position.y, scale*package_in_base.pose.position.z] #0.257
    print(package_in_base_coords)
    package_in_base_mat = []
    # package_in_base_mat = rotation_matrix@package_in_base_coords
    package_in_base_mat = rotation_matrix@package_in_base_coords + translation_vector
    if package_in_base_mat[2] < 0.1:
        package_in_base_mat[2] = 0.02
    print(f"Target: {package_in_base_mat[0]}, {package_in_base_mat[1]}, {package_in_base_mat[2]}")
    return package_in_base_mat

def trajectory():
    p1 = controller()
    t1 = rospy.Time.now().to_sec()
    rospy.sleep(0.5)

    p2 = controller()
    t2 = rospy.Time.now().to_sec()
    delta_t = t2 -t1
    print(p1,p2)

    if not p1 is None and not p2 is None:
        velocity = (p2[1] - p1[1])/delta_t
    else:
        velocity = 0
    t = rospy.Time.now().to_sec() - t2
    return p2, velocity, t

# Python's syntax for a main() method
if __name__ == '__main__':
    rospy.init_node('control', anonymous=True)
    # package_coords = controller()
    # print(package_coords)
    # while not rospy.is_shutdown():
    #     try : 
    #         Trajectory()
    #     except Exception as e:
    #         print("got exception", e)
    #     rospy.sleep(2.0)
        # Set up the right gripper
    right_gripper = robot_gripper.Gripper('right_gripper')
    # Calibrate the gripper (other commands won't work unless you do this first)
    print('Calibrating...')
    right_gripper.calibrate()
    rospy.sleep(2.0)

    # while(True):
    #     p2, velocity, t = trajectory()
    #     if velocity != 0:
    #         test(p2, velocity, t, right_gripper)


    p2, velocity, t = trajectory()
    if velocity != 0:
        test(p2, velocity, t, right_gripper)


    # base = np.array([0.1786,0.7379,3.2248])
    # package = np.array([0.45485,-0.08796,1.3979])
    # test = base-package
    # test[1] = test[1]-0.96
    # test[2] = test[2]*-0.07
    # print(test)
    
    # rotation_matrix = np.array([[1,0,0],[0,-1,0],[0,0,-1]])
    # t = package-base
    # # t = t@rotation_matrix
    # t = np.array([t[1],t[0],t[2]])
    # print(t)
    # print(rotation_matrix@package-t)
    # rospy.sleep(3)
    
    rospy.spin()
  