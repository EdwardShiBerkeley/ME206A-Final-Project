#!/usr/bin/env python
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from ar_track_alvar_msgs.msg import AlvarMarkers
from geometry_msgs.msg import Point


class ObjectTracker:
    def __init__(self):
        self.bridge = CvBridge()
        self.ar_subscriber = rospy.Subscriber(
            '/ar_pose_marker', AlvarMarkers, self.ar_callback)
        self.position_publisher = rospy.Publisher(
            '/package_position', Point, queue_size=10)

    def ar_callback(self, data):
        for marker in data.markers:
            if marker.id == package_ar_tag_id:  # Replace with our package's AR tag ID
                position = marker.pose.pose.position
                self.position_publisher.publish(position)


if __name__ == '__main__':
    rospy.init_node('object_tracker')
    package_ar_tag_id = 'ar_marker_PACKAGE'  # Replace with the package's AR tag ID
    tracker = ObjectTracker()
    rospy.spin()
