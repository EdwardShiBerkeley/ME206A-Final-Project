#!/usr/bin/env python
#from geometry_msgs.msg import Twist
import numpy as np
import rospy
from std_srvs.srv import Empty
from turtle_patrol.srv import Patrol  # Service type
from turtlesim.srv import TeleportAbsolute
from geometry_msgs.msg import Twist
import sys

turtle_name = sys.argv[1]

def coords_callback(request):
#    NAME = request.name
    rospy.wait_for_service('clear')
    rospy.wait_for_service(f'{turtle_name}/teleport_absolute')
    clear_proxy = rospy.ServiceProxy('clear', Empty)
    teleport_proxy = rospy.ServiceProxy(
        f'/{turtle_name}/teleport_absolute',
        TeleportAbsolute
    )
    vel = request.vel  # Linear velocity
    omega = request.omega  # Angular velocity
    x = request.x
    y = request.y
    theta = request.theta
    pub = rospy.Publisher(
        f'/{turtle_name}/cmd_vel', Twist, queue_size=50)
    cmd = Twist()
    cmd.linear.x = vel
    cmd.angular.z = omega
    # Publish to cmd_vel at 5 Hz
    rate = rospy.Rate(5)
    # Teleport to initial pose
    #teleport_proxy(9, 5, np.pi/2)
    teleport_proxy(x, y, theta)
    
    # Clear historical path traces
    clear_proxy()
    while not rospy.is_shutdown():
        pub.publish(cmd)  # Publish to cmd_vel
        rate.sleep()  # Sleep until 
    return cmd  # This line will never be reached, then call "cmd = patrol_proxy(vel, omega, x, y, theta)" to get the cmd in the client file


    tfBuffer = tf2_ros.Buffer() ## TODO: initialize a buffer
    tfListener = tf2_ros.TransformListener(tfBuffer) ## TODO: initialize a tf listener

    # Create a timer object that will sleep long enough to result in
    # a 10Hz publishing rate
    r = rospy.Rate(10) # 10hz
    # you can also use the rate to calculate your dt, but you don't have to
    #                                              target_frame, source_frame, current_time_in_ros
    trans_camera_to_base = tfBuffer.lookup_transform("ar_marker_3", "usb_cam", rospy.Time(), rospy.Duration(10)) ## TODO: create a transform between odom to base link
    prev = [0,0,0]
    while not rospy.is_shutdown():
        try:
            trans_package_to_camera0 = tfBuffer.lookup_transform("usb_cam", "ar_marker_0", rospy.Time(), rospy.Duration(1))
            trans_package_to_camera0_coords = [trans_package_to_camera0.transform.translation.x,trans_package_to_camera0.transform.translation.y,trans_package_to_camera0.transform.translation.z]
            # print(abs(np.linalg.norm(trans_package_to_camera0_coords-prev))
            # a = abs(np.linalg.norm(trans_package_to_camera0_coords - prev))
            prev = [trans_package_to_camera0]
            if trans_package_to_camera0 == prev:
                trans_package_to_camera0 = None
            # trans_package_to_camera1 = tfBuffer.lookup_transform("usb_cam", "ar_marker_1", rospy.Time(), rospy.Duration(10))
            # trans_package_to_camera2 = tfBuffer.lookup_transform("usb_cam", "ar_marker_2", rospy.Time(), rospy.Duration(10))

            # trans_package_to_camera_arr = [trans_package_to_camera0 trans_package_to_camera1 trans_package_to_camera2]
            if trans_package_to_camera0 == None:
                trans_package_to_camera_arr = []
            else:
                trans_package_to_camera_arr = [trans_package_to_camera0]

            package_trans_arr = []

            for i in range(len(trans_package_to_camera_arr)):
                package_trans = PoseStamped() ## TODO: initialize a PoseStamped
                package_trans.pose.position.x = trans_package_to_camera_arr[i].transform.translation.x ## TODO: what value would you use here?
                package_trans.pose.position.y = trans_package_to_camera_arr[i].transform.translation.y ## TODO: what value would you use here?
                package_trans.pose.position.z = trans_package_to_camera_arr[i].transform.translation.z ## TODO: what value would you use here?  # Assuming the waypoint is on the ground
                package_trans.pose.orientation.x = trans_package_to_camera_arr[i].transform.rotation.x ## TODO: what value would you use here?
                package_trans.pose.orientation.y = trans_package_to_camera_arr[i].transform.rotation.y ## TODO: what value would you use here?
                package_trans.pose.orientation.z = trans_package_to_camera_arr[i].transform.rotation.z ## TODO: what value would you use here?
                package_trans.pose.orientation.w = trans_package_to_camera_arr[i].transform.rotation.w ## TODO: what value would you use here?


                # trans_arTag_to_base = TransformStamped()
                # roll = np.pi/2
                # pitch = 0
                # baselink_yaw = np.pi/2
                # quat = quaternion_from_euler(roll, pitch, baselink_yaw)
                # trans_arTag_to_base.transform.translation.x = 0.144
                # trans_arTag_to_base.transform.translation.y = 0
                # trans_arTag_to_base.transform.translation.z = 0
                # trans_arTag_to_base.transform.rotation.x = quat[0]
                # trans_arTag_to_base.transform.rotation.y = quat[1]
                # trans_arTag_to_base.transform.rotation.z = quat[2]
                # trans_arTag_to_base.transform.rotation.w = quat[3]

                # print(trans_camera_to_base)
                # print(trans_package_to_camera)

                # Use the transform to compute the waypoint's pose in the base_link frame
                # package_in_base = do_transform_pose(package_trans, trans_camera_to_base) ## TODO: what would be the inputs to this function (there are 2)

                package_in_base = do_transform_pose(package_trans, trans_camera_to_base) ## TODO: what would be the inputs to this function (there are 2)
                print(f"Target: {package_in_base.pose.position.x}, {package_in_base.pose.position.y}, {package_in_base.pose.position.z}")
                # print(f"Target: {trans_package_to_base.transform.translation.x}, {trans_package_to_base.transform.translation.y}, {trans_package_to_base.transform.translation.z}")


                rotation_matrix = np.array([[0,0,1],[1,0,0],[0,1,0]])
                # NOTE: MANUALLY FIND OFFSET BY PUTTING ROBOT END EFFECTOR TO AR BASE TAG AND ADDING OFFSET VALUES BELOW
                translation_vector = np.array([0.17, 0.015, 0.026+0.05])
                package_in_base_coords = [0.257*package_in_base.pose.position.x, 0.257*package_in_base.pose.position.y, 0.257*package_in_base.pose.position.z]
                package_in_base_mat = rotation_matrix@package_in_base_coords + translation_vector

                package_trans_arr.append(package_in_base_mat)

            # package_in_base = do_transform_pose(package_in_base, trans_arTag_to_base) ## TODO: what would be the inputs to this function (there are 2)
            # print(f"Target: {package_in_base.pose.position.x}, {package_in_base.pose.position.y}, {package_in_base.pose.position.z}")


            # package_in_base = do_transform_pose(package_in_base, rotationTransform) ## TODO: what would be the inputs to this function (there are 2)
            if len(package_trans_arr) != 0:
                print(f"Target: {package_trans_arr[0][0]}, {package_trans_arr[0][1]}, {package_trans_arr[0][2]}")
            # print(f"Target: {package_in_base_mat[0]}, {package_in_base_mat[1]}, {package_in_base_mat[2]}")
            rospy.sleep(0.1)
    # return trans_camera_to_base
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
          # print("TF Error in Controller: " + str(e))
          pass
    
    return package_in_base_mat

def camera_server():
    # Initialize the server node for turtle1
    rospy.init_node('camera_server')
    # Register service
    rospy.Service(
        'package_coords',  # Service name
        Package_coords,  # Service type
        coords_callback  # Service callback
    )
    rospy.loginfo('Running camera server...')
    rospy.spin() # Spin the node until Ctrl-C


if __name__ == '__main__':
    camera_server()

