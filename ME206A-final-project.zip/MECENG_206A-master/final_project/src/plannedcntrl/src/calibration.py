#!/usr/bin/env python
import rospy
import tf2_ros
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from ar_track_alvar_msgs.msg import AlvarMarkers
import numpy as np
import tf.transformations as tf_trans
from geometry_msgs.msg import Pose, Point, Quaternion


class Calibration:
    def __init__(self):
        self.bridge = CvBridge()
        self.camera_service = rospy.ServiceProxy('last_image', ImageSrv)
        self.tfBuffer = tf2_ros.Buffer()
        self.tfListener = tf2_ros.TransformListener(self.tfBuffer)
        self.ar_tag_positions = {'base': None, 'gripper': None}
        self.ar_subscriber = rospy.Subscriber(
            '/ar_pose_marker', AlvarMarkers, self.ar_callback)

    def ar_callback(self, data):
        for marker in data.markers:
            if marker.id == "ar_marker_3":  # Our base tag ID
                self.ar_tag_positions['base'] = marker.pose.pose
            if marker.id == gripper_tag_id:  # Replace with our gripper tag ID
                self.ar_tag_positions['gripper'] = marker.pose.pose

    def perform_calibration(self):
        rospy.sleep(2)  # Wait for AR tag data

        if self.ar_tag_positions['base'] and self.ar_tag_positions['gripper']:
            # Robot base and gripper positions in robot frame
            known_base_pos_robot_frame = np.array(
                [0, 0, 0])  # Base is at origin
            known_gripper_pos_robot_frame = np.array(
                [0.556, 0.034, -0.129])  # Gripper position

            # AR tag positions in camera frame
            camera_base_pos = np.array([self.ar_tag_positions['base'].position.x,
                                        self.ar_tag_positions['base'].position.y,
                                        self.ar_tag_positions['base'].position.z])
            camera_gripper_pos = np.array([self.ar_tag_positions['gripper'].position.x,
                                           self.ar_tag_positions['gripper'].position.y,
                                           self.ar_tag_positions['gripper'].position.z])

            # Calculate translation and rotation
            translation = known_base_pos_robot_frame - camera_base_pos
            rotation = tf_trans.rotation_matrix(tf_trans.angle_between_vectors(
                known_gripper_pos_robot_frame - known_base_pos_robot_frame,
                camera_gripper_pos - camera_base_pos), axis=[0, 0, 1])

            # Transformation matrix
            transformation_matrix = tf_trans.concatenate_matrices(
                tf_trans.translation_matrix(translation), rotation)

            print("Calibration Transformation Matrix:")
            print(transformation_matrix)
        else:
            rospy.logwarn("AR tag positions not available.")

    def get_base_position(self):
        try:
            # Assuming 'base' is the TF frame name of the robot's base
            trans = self.tfBuffer.lookup_transform(
                'world', 'base', rospy.Time(0), rospy.Duration(1.0))
            return np.array([trans.transform.translation.x, trans.transform.translation.y, trans.transform.translation.z])
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
            rospy.logwarn(f"TF Error in get_base_position: {e}")
            return None

    def get_gripper_position(self):
        try:
            # Assuming 'right_gripper_tip' is the TF frame name of the gripper's tip
            trans = self.tfBuffer.lookup_transform(
                'world', 'right_gripper_tip', rospy.Time(0), rospy.Duration(1.0))
            return np.array([trans.transform.translation.x, trans.transform.translation.y, trans.transform.translation.z])
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
            rospy.logwarn(f"TF Error in get_gripper_position: {e}")
            return None


if __name__ == '__main__':
    rospy.init_node('calibration_node')
    base_tag_id = "ar_marker_BASE"  # Update with actual base tag ID
    gripper_tag_id = "ar_marker_GRIPPER"  # Update with actual gripper tag ID
    calibrator = Calibration()
    calibrator.perform_calibration()
