
"use strict";

let ImageSrv = require('./ImageSrv.js')

module.exports = {
  ImageSrv: ImageSrv,
};
